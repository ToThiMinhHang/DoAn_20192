package com.hang.doan.readbooks.presenter;

import com.hang.doan.readbooks.models.StoryDetail;

import java.util.List;

public interface StoryDetailPresenter {

    public List<StoryDetail> downLoadData();

}

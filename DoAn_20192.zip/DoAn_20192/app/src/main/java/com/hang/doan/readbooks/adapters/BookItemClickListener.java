package com.hang.doan.readbooks.adapters;

import android.widget.ImageView;

import com.hang.doan.readbooks.models.Books;

public interface BookItemClickListener {

    void onBookClick(Books book, ImageView bookImageView); // we will need the imageview to make the shared animation between the two activity

}
